# Let's see Paul Allen's card...

A Pen created on CodePen.io. Original URL: [https://codepen.io/johnslipper/pen/zYzBJa](https://codepen.io/johnslipper/pen/zYzBJa).

Look at that subtle off-white coloring. The tasteful thickness of it. Oh, my God. It even has a watermark.

Is something wrong, Patrick? You're sweating.

Forked from [Russ Beye](/russbeye)'s Pen [New Card. What do you think?](/russbeye/pen/mAvku/).