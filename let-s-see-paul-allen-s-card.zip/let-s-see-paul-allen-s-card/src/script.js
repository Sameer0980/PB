/*
Look at that subtle off-white coloring. The tasteful thickness of it. Oh, my God. It even has a watermark.

Is something wrong, Patrick? You're sweating.
*/